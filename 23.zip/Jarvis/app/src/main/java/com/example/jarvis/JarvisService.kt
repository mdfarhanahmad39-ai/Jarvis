package com.example.jarvis

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class JarvisService : Service(), TextToSpeech.OnInitListener {
    companion object {
        @Volatile var running = false
        const val STOP = "jarvis.STOP"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var rec: SpeechRecognizer? = null
    private var speaking = false
    private var busy = false
    private var quitAfter = false
    private var sayId = 0
    private var activeUntil = 0L
    private val hist = ArrayList<Pair<String, String>>()
    private val wake = Regex("^(.*?)\\bj[ae]r[vw]is\\b[\\s,.]*(.*)$", RegexOption.IGNORE_CASE)
    private val again = Runnable { listen() }
    private val SYS = "You are J.A.R.V.I.S., the dry-witted British AI butler from Iron Man, running as a voice app on the user's Android phone. Always address the user as 'sir'. Be polite, capable and subtly witty. Reply in 1 to 3 short sentences of plain text with no markdown, lists or emoji, because your reply is read aloud. Give more detail only if asked. You cannot control phone settings or other apps beyond what the app already does; do not claim to."

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("j", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, JarvisService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "j")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis").setContentText("Listening for \"Jarvis\"")
            .setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Stop", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        running = true
        listen()
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        t.language = Locale.UK
        t.voices?.firstOrNull { it.locale.country == "GB" && it.name.contains("male", true) && !it.name.contains("female", true) }?.let { t.voice = it }
        t.setPitch(0.85f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { main.post { done() } }
            override fun onError(u: String?) { main.post { done() } }
        })
        ttsReady = true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        say((if (h < 12) "Good morning" else if (h < 18) "Good afternoon" else "Good evening") + ", sir. All systems are online. Say my name whenever you need me.")
    }

    // ---- speech in / out ----
    private fun listen() {
        if (!running || speaking) return
        try {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(b: Bundle?) {
                        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard(it) }
                        if (!speaking) restart(250)
                    }
                    override fun onError(e: Int) { if (!speaking) restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 300) }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(b: Bundle?) {}
                    override fun onEvent(t: Int, b: Bundle?) {}
                })
                startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US"))
            }
        } catch (e: Exception) { restart(2000) }
    }

    private fun restart(ms: Long) { main.removeCallbacks(again); main.postDelayed(again, ms) }

    private fun say(t: String) {
        if (!running) return
        speaking = true
        rec?.cancel()
        val id = ++sayId
        val ok = ttsReady && tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u$id") == TextToSpeech.SUCCESS
        if (!ok) { done(); return }
        main.postDelayed({ if (speaking && id == sayId) done() }, 3000L + t.length * 100L)
    }

    private fun done() {
        if (quitAfter) { stopSelf(); return }
        speaking = false
        activeUntil = System.currentTimeMillis() + 8000
        restart(300)
    }

    private fun heard(t0: String) {
        val t = t0.trim()
        if (t.isEmpty() || busy || speaking) return
        val m = wake.find(t)
        if (m != null) {
            val c = m.groupValues[2].trim()
            if (c.isEmpty()) say("Yes, sir?") else handle(c)
        } else if (System.currentTimeMillis() < activeUntil) handle(t)
    }

    // ---- commands ----
    private fun findApp(name: String): Intent? {
        val pm = packageManager
        val hit = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name.lowercase()) }
        return hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
    }

    private fun ctl(): JarvisAccess? {
        val a = JarvisAccess.inst
        if (a == null) say("Full control is not switched on, sir. Please enable it in the app.")
        return a
    }

    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Exception) { say("I could not open that, sir.") }
    }
    private fun view(u: String) = go(Intent(Intent.ACTION_VIEW, Uri.parse(u)))

    private fun handle(raw: String) {
        val q = raw.lowercase().replace(Regex("[?.!,]"), "").removePrefix("please ").trim()
        fun m(r: String) = Regex(r).find(q)
        fun has(r: String) = Regex(r).containsMatchIn(q)
        var x: MatchResult?

        if (has("^(stop|quiet|be quiet|shut up)$")) { tts?.stop(); speaking = false; restart(100); return }
        if (has("stand ?by|go to sleep|shut down|that will be all|that is all")) { quitAfter = true; say("Very good, sir. Standing by."); return }
        if (has("status|system report|diagnostic")) {
            val bm = getSystemService(BatteryManager::class.java)
            val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            say("All systems are nominal, sir. Battery is at $lvl percent" + (if (bm.isCharging) " and charging" else "") +
                ". The time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + "."); return
        }
        if (has("what time|^time$|the time")) { say("It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + ", sir."); return }
        if (has("(what|which|today).*(date|day)")) { say("Today is " + SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()) + ", sir."); return }
        x = m("timer for (\\w+(?:\\.\\d+)?) (second|minute|hour)s?")
        if (x != null) {
            val words = mapOf("one" to 1.0, "two" to 2.0, "three" to 3.0, "four" to 4.0, "five" to 5.0, "six" to 6.0, "seven" to 7.0, "eight" to 8.0, "nine" to 9.0, "ten" to 10.0, "fifteen" to 15.0, "twenty" to 20.0, "thirty" to 30.0, "sixty" to 60.0)
            val n = words[x.groupValues[1]] ?: x.groupValues[1].toDoubleOrNull()
            if (n == null) { say("I did not catch the duration, sir."); return }
            val unit = x.groupValues[2]
            val ms = (n * mapOf("second" to 1, "minute" to 60, "hour" to 3600)[unit]!! * 1000).toLong()
            main.postDelayed({ say("Sir, your $n $unit timer has finished.") }, ms)
            say("Timer set, sir."); return
        }
        if (has("flashlight|torch")) {
            val on = !has("\\boff\\b")
            try { val cm = getSystemService(CameraManager::class.java); cm.setTorchMode(cm.cameraIdList[0], on); say("Flashlight " + (if (on) "on" else "off") + ", sir.") }
            catch (e: Exception) { say("The flashlight is not responding, sir.") }
            return
        }
        if (has("volume (up|down)")) {
            val am = getSystemService(AudioManager::class.java)
            repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (has("up")) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
            say("Very good, sir."); return
        }
        if (has("^(go )?(home|home screen)$|go home")) { ctl()?.let { it.home(); say("Home screen, sir.") }; return }
        if (has("^(go )?back$")) { ctl()?.let { it.back(); say("Going back, sir.") }; return }
        if (has("recent apps|recents|app switcher")) { ctl()?.let { it.recents(); say("Recent apps, sir.") }; return }
        if (has("(open|show|pull down) (the )?(notifications|notification shade)")) { ctl()?.let { it.notifications(); say("Notifications, sir.") }; return }
        if (has("^(scroll|swipe) (down|up)$")) { val fwd = has("down"); ctl()?.let { say(if (it.scroll(fwd)) "Scrolling, sir." else "Nothing to scroll here, sir.") }; return }
        if (has("read (the )?screen|on (the|my) screen")) {
            ctl()?.let { val t = it.readScreen(); say(if (t.isBlank()) "I cannot see any text on the screen, sir." else t) }; return
        }
        if (has("^send( it| the message| message)?$")) { ctl()?.let { say(if (it.tap("send")) "Sent, sir." else "I cannot find a send button, sir.") }; return }
        x = m("^(?:tap on|click on|tap|click|press) (.+)")
        if (x != null) {
            val lbl = x.groupValues[1]
            if (Regex("pay|transfer|purchase|buy|delete|uninstall|reset").containsMatchIn(lbl)) { say("I will not tap that on my own, sir. Please do it yourself."); return }
            ctl()?.let { say(if (it.tap(lbl)) "Done, sir." else "I cannot see $lbl on the screen, sir.") }
            return
        }
        x = m("^type (.+)")
        if (x != null) {
            val txt = x.groupValues[1]
            ctl()?.let { say(if (it.type(txt)) "Typed, sir." else "There is no text box in focus, sir.") }
            return
        }
        x = m("^(?:remember|note|remind me)(?: that| to)? (.+)")
        if (x != null) { prefs.edit().putString("notes", (prefs.getString("notes", "") ?: "") + x.groupValues[1] + "\n").apply(); say("Noted, sir."); return }
        if (has("(show|read|list|what are) (my )?notes")) {
            val n = (prefs.getString("notes", "") ?: "").trim()
            say(if (n.isEmpty()) "You have no notes, sir." else "Your notes, sir. " + n.split("\n").joinToString(". ")); return
        }
        if (has("(clear|delete) (my )?notes")) { prefs.edit().remove("notes").apply(); say("Notes cleared, sir."); return }
        x = m("^(?:call|phone|dial) (.+)")
        if (x != null) { val d = x.groupValues[1].filter { it.isDigit() }; if (d.length < 3) say("Please give me the number, sir.") else { say("Dialing, sir."); view("tel:$d") }; return }
        x = m("^(?:navigate to|directions to|take me to|where is) (.+)")
        if (x != null) { say("Plotting a route, sir."); view("google.navigation:q=" + Uri.encode(x.groupValues[1])); return }
        x = m("^(?:play|watch) (.+?)(?: on youtube)?$")
        if (x != null) { say("Pulling that up, sir."); view("https://www.youtube.com/results?search_query=" + Uri.encode(x.groupValues[1])); return }
        x = m("^open (.+)")
        if (x != null) {
            val name = x.groupValues[1]
            val pm = packageManager
            val hit = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            val li = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (li == null) say("I cannot find $name on this device, sir.") else { say("Opening $name, sir."); go(li) }
            return
        }
        x = m("^(?:search|find|look up|look for)(?: for)? (.+?) (?:on|in) (.+)$")
        if (x != null) {
            val term = x.groupValues[1]
            val app = x.groupValues[2].trim()
            if (app.contains("youtube")) { say("Searching YouTube, sir."); view("https://www.youtube.com/results?search_query=" + Uri.encode(term)); return }
            if (app.contains("maps")) { say("Searching maps, sir."); view("geo:0,0?q=" + Uri.encode(term)); return }
            if (app.contains("google")) { say("Searching, sir."); view("https://www.google.com/search?q=" + Uri.encode(term)); return }
            val li = findApp(app)
            if (li == null) { say("I cannot find $app on this device, sir."); return }
            if (JarvisAccess.inst == null) { say("I need full control switched on to search inside $app, sir."); return }
            say("Searching $app for $term, sir.")
            go(li)
            main.postDelayed({ JarvisAccess.inst?.tap("search") }, 3500)
            main.postDelayed({ JarvisAccess.inst?.type(term) }, 4800)
            return
        }
        x = m("^(?:search|google|look up|search for) (.+)")
        if (x != null) { say("Searching, sir."); view("https://www.google.com/search?q=" + Uri.encode(x.groupValues[1])); return }
        x = m("^weather(?: in| for)? ?(.*)")
        if (x != null) { say("Checking the forecast, sir."); view("https://www.google.com/search?q=" + Uri.encode("weather " + x.groupValues[1])); return }
        chat(raw)
    }

    // ---- conversation (Claude API, user's own key) ----
    private fun chat(raw: String) {
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) { say("I need an API key to converse, sir. Please add one in the app."); return }
        busy = true
        hist.add("user" to raw)
        while (hist.size > 12) hist.removeAt(0)
        while (hist.isNotEmpty() && hist[0].first != "user") hist.removeAt(0)
        val snap = ArrayList(hist)
        Thread {
            val out: String? = try {
                val msgs = JSONArray()
                snap.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
                val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 300).put("system", SYS).put("messages", msgs)
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 30000; c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode !in 200..299) throw RuntimeException("HTTP " + c.responseCode)
                JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("content").getJSONObject(0).getString("text").replace(Regex("[*#`_]"), "").trim()
            } catch (e: Exception) { null }
            main.post {
                busy = false
                if (out == null) { hist.removeAt(hist.size - 1); say("I could not reach my conversational core, sir. Please check the connection and the API key.") }
                else { hist.add("assistant" to out); say(out) }
            }
        }.start()
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        rec?.destroy(); tts?.shutdown()
        super.onDestroy()
    }
}
