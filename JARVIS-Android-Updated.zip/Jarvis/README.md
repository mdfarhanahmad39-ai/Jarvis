# JARVIS Android app (updated source)

## What's changed
- British English Text-to-Speech voices are prioritised when cycling voices.
- Speech pitch and rate are adjusted for a calmer, lower, slower delivery. The actual voice depends on voices installed on the Android phone.
- Conversational system instructions now encourage direct answers to general questions and study questions.
- Notes saved with the app's remember/note command are included as context in Claude conversations.
- Removed the bundled default debug signing keystore configuration. GitHub Actions will use its own generated debug key.

## Important
- Conversational Q&A requires a valid Anthropic API key and internet access. API usage may cost money. Do not put an API key in source code, GitHub, screenshots, or public issues.
- Speech recognition depends on the Android speech-recognition provider and may use network services.
- The selected British voice is only available if an appropriate English (UK) voice is installed on the phone. Android's pitch/rate controls do not synthesize a new voice.
- Accessibility permission is powerful. Enable it only if you understand and want the phone-control features. Keep confirmations for sensitive actions.

## Build on GitHub
1. Create or open a private GitHub repository.
2. Upload the contents of the `Jarvis` folder (not the outer ZIP folder).
3. Open the repository's **Actions** tab and wait for **Build APK** to finish.
4. Open the successful workflow run, open **Artifacts**, and download `jarvis-apk`.
5. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

The workflow builds a debug APK for testing. It is not a Play Store release build.
