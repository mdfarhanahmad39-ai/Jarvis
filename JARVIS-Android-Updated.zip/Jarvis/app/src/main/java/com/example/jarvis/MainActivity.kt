package com.example.jarvis

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var status: TextView
    private lateinit var key: EditText
    private lateinit var info: TextView
    private var tts: TextToSpeech? = null
    private var vIdx = 0

    private fun nextVoice() {
        if (tts == null) {
            tts = TextToSpeech(this) { st ->
                if (st == TextToSpeech.SUCCESS) { tts?.language = Locale.UK; cycleVoice() }
                else status.text = "No text to speech engine found, sir."
            }
            return
        }
        cycleVoice()
    }

    private fun cycleVoice() {
        val t = tts ?: return
        val vs = (t.voices ?: emptySet())
            .filter { it.locale.language == "en" }
            .sortedWith(compareBy(
                { it.locale.country != "GB" },
                { it.name.contains("female", ignoreCase = true) },
                { !it.name.contains("male", ignoreCase = true) },
                { it.name }
            ))
        if (vs.isEmpty()) { status.text = "No English voices installed."; return }
        val v = vs[vIdx % vs.size]; vIdx++
        t.voice = v
        t.setPitch(0.78f)
        t.setSpeechRate(0.92f)
        getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("voice", v.name).apply()
        status.text = "Voice " + vIdx + " of " + vs.size + ": " + v.name
        t.speak("Good evening, sir. How may I help you?", TextToSpeech.QUEUE_FLUSH, null, "p")
    }

    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val ac = Color.parseColor("#5EE7FF")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#04101B"))
            setPadding(dp(24), dp(48), dp(24), dp(24))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply { text = "J.A.R.V.I.S."; setTextColor(ac); textSize = 22f; letterSpacing = 0.3f })
        root.addView(Orb(this), LinearLayout.LayoutParams(dp(240), dp(240)).apply { topMargin = dp(16) })
        status = TextView(this).apply { setTextColor(ac); textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)) }
        root.addView(status)
        key = EditText(this).apply {
            hint = "Anthropic API key (for conversation)"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        root.addView(key, LinearLayout.LayoutParams(-1, -2))
        info = TextView(this).apply { setTextColor(Color.GRAY); textSize = 13f; setPadding(0, dp(12), 0, 0) }
        root.addView(info)
        btn = Button(this)
        root.addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        root.addView(Button(this).apply {
            text = "Allow display over other apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            }
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "Turn on full control (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "Choose JARVIS voice (British first)"
            setOnClickListener { nextVoice() }
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#04101B")); addView(root) })

        btn.setOnClickListener {
            if (JarvisService.running) {
                startService(Intent(this, JarvisService::class.java).setAction(JarvisService.STOP))
            } else {
                prefs.edit().putString("key", key.text.toString().trim()).apply()
                val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
                if (need.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED })
                    requestPermissions(need.toTypedArray(), 1)
                else begin()
            }
            btn.postDelayed({ refresh() }, 600)
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) begin()
        else status.text = "Microphone permission is required, sir."
        btn.postDelayed({ refresh() }, 600)
    }

    private fun begin() = startForegroundService(Intent(this, JarvisService::class.java))
    private val tick = object : Runnable {
        override fun run() { info.text = "Build 7\nHeard: " + JarvisService.lastHeard; info.postDelayed(this, 1000) }
    }
    override fun onResume() { super.onResume(); refresh(); tick.run() }
    override fun onPause() { info.removeCallbacks(tick); super.onPause() }
    private fun refresh() {
        val on = JarvisService.running
        btn.text = if (on) "Stand by" else "Initialize"
        status.text = if (on) "Listening for \u201CJarvis\u201D" else "Standing by"
    }
}

class Orb(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.parseColor("#5EE7FF") }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#5EE7FF") }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 12000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy) * 0.95f
        val on = JarvisService.running
        p.alpha = if (on) 255 else 100
        fun ring(f: Float, w: Float, a: Float, b: Float, rot: Float) {
            p.strokeWidth = w; p.pathEffect = DashPathEffect(floatArrayOf(a, b), 0f)
            c.save(); c.rotate(rot, cx, cy); c.drawCircle(cx, cy, r * f, p); c.restore()
        }
        ring(1f, 3f, 8f, 24f, t); ring(0.84f, 8f, 180f, 40f, -t * 2)
        ring(0.66f, 3f, 4f, 14f, t * 3); ring(0.5f, 10f, 90f, 200f, t * 5)
        core.alpha = if (on) 140 + (Math.sin(Math.toRadians(t * 10.0)) * 60).toInt() else 50
        c.drawCircle(cx, cy, r * 0.28f, core)
    }
}
