package com.example.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Acts only when JarvisService calls it after a voice command. It never records,
// stores or transmits what is on screen.
class JarvisAccess : AccessibilityService() {
    companion object { @Volatile var inst: JarvisAccess? = null }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), out)
    }
    private fun nodes(): List<AccessibilityNodeInfo> { val l = ArrayList<AccessibilityNodeInfo>(); walk(rootInActiveWindow, l); return l }
    private fun label(n: AccessibilityNodeInfo) = (n.text ?: n.contentDescription)?.toString()?.lowercase() ?: ""

    fun tap(want: String): Boolean {
        val t = want.lowercase().trim()
        var n: AccessibilityNodeInfo? = nodes().filter { !it.isPassword && label(it).contains(t) }.minByOrNull { label(it).length }
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    fun type(text: String): Boolean {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: nodes().firstOrNull { it.isEditable } ?: return false
        if (n.isPassword) return false
        val cur = if (n.isShowingHintText) "" else n.text?.toString() ?: ""
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, if (cur.isEmpty()) text else "$cur $text")
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun scroll(forward: Boolean): Boolean {
        val n = nodes().firstOrNull { it.isScrollable } ?: return false
        return n.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun readScreen(): String {
        val seen = LinkedHashSet<String>()
        for (n in nodes()) {
            if (n.isPassword) continue
            val s = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!s.isNullOrEmpty() && s.length < 200) seen.add(s)
            if (seen.size >= 15) break
        }
        return seen.joinToString(". ")
    }
}
